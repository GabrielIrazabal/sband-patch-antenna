%TF.GenerationSoftware,KiCad,Pcbnew,10.0.6*%
%TF.CreationDate,2026-11-24T20:03:28-08:00*%
%TF.ProjectId,A_dualfeed_PTFE_3mm_BOTTOM,415f6475-616c-4666-9565-645f50544645,rev?*%
%TF.SameCoordinates,Original*%
%TF.FileFunction,Soldermask,Top*%
%TF.FilePolarity,Negative*%
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.6) date 2026-11-24 20:03:28*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,3.200000*%
G04 APERTURE END LIST*
D10*
%TO.C,H1*%
X104000000Y-104000000D03*
%TD*%
%TO.C,H2*%
X156000000Y-104000000D03*
%TD*%
%TO.C,H3*%
X156000000Y-156000000D03*
%TD*%
%TO.C,H4*%
X104000000Y-156000000D03*
%TD*%
M02*
